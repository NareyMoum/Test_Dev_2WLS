<?php


 namespace App\Validator;

use Symfony\Component\Validator\ConstraintValidator;
use Symfony\Component\Validator\Exception\UnexpectedTypeException;
use Symfony\Component\Validator\Exception\UnexpectedValueException;
use Symfony\Component\Validator\Constraint;

/**
 * @Annotation
 */
class ValidateDate extends ConstraintValidator
{
    public $message = 'The string "{{ string }}" contains an illegal character: it can only contain letters or numbers.';
    public $mode = 'strict'; // If the constraint has configuration options, define them as public properties

    function valid_date($input_date) {

        if(!preg_match('/(?P<d>\d{2})(?P<sep>\D)(?P<m>\d{2})\2(?P<y>\d{4})/',$input_date, $aux_date))
            return false;
        $aux = mktime(0,0,0,$aux_date['m'],$aux_date['d'],$aux_date['y']);
        return $input_date == date('d'.$aux_date['sep'].'m'.$aux_date['sep'].'Y',$aux);
    }
    /**
     * @inheritDoc
     */
    public function validate($value, Constraint $constraint)
    {

        if( !$this->valid_date($value) )
        {
            $this->context->buildViolation($constraint->message)
                ->setParameter('{{ string }}', $value)
                ->addViolation();
        }
     }
}